greeting="hello world"
print("greeting is {}.".format(greeting))